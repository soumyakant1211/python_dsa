l1 = []

print(l1)
print(l1.pop())
print(l1)