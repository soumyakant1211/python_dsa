
# print(abs(hash('abc')))

d = {}
# d[[1,2,3]] = 1
# print(hash([1,2,3]))

d1 = {}

d1['apple'] = 20 # __setitem__ , sending key and value here

print(d1['apple']) # __getitem__ sending just the key here

print(d1)