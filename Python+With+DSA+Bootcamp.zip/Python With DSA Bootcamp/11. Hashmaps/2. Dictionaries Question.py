
## 1. Intersection Of Two Arrays
def intersection_of_arrays(arr1, arr2):
    pass

# Example Usage:
arr1 = [1, 2, 2, 1]
arr2 = [2, 2]
print(intersection_of_arrays(arr1, arr2))


# 2. Check for Duplicates

def contains_duplicates(nums): 
    pass

# Example Usage:
nums1 = [1, 2, 3, 1]
nums2 = [1, 2, 3, 4]
print(contains_duplicates(nums1))  # Output: True
print(contains_duplicates(nums2))  # Output: False


# 3. First None Repeating Character in a string

def first_non_repeating_char(s):
    pass

# Example Usage:
s = "swiss"
print(first_non_repeating_char(s)) # 'w'


