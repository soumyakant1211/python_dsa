from predefinedBSTs import create_predefined_bsts_manual

root1,root2,root3 = create_predefined_bsts_manual()

def search_in_BST(root,value):
    pass