import sys

# l1 =[]

# # print("initial size",sys.getsizeof(l1))

# # for i in range(0,17):
# #     l1.append(i)
# #     print(f"{i} --> {sys.getsizeof(l1)} ")


# a = 1

# l1.append(1)

# print(id(1))
# a =2
# print(id(a))
# print(id(l1[0]))
# l1.append("python")
# print(l1)

s = "python"
(s[:-1])

l1 = [10,20,30,40,50]

print(l1.pop())
print(l1)

# Indexing behaviour

# print(l1[10])



# Clear

l2 = [100,200,300]
print(l2)
l2.clear()
print(l2)


# Insert
print("Insert")
l3 = [100,200,300]
l3.insert(1,500)
print(l3)
print()
print()


# Remove

l3.remove(500)
print(l3)