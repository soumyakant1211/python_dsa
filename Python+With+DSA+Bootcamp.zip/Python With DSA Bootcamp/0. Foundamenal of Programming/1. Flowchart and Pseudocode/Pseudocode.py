'''

Begin
    Input FirstNumber
    Input SecondNumber

    SUM = FirstNumber + SecondNumber

    print SUM

End

'''