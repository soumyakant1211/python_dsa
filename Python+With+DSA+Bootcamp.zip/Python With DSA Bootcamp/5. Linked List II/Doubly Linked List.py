class DoubleLLNode:
    def __init__(self,value):
        self.data =value
        self.next = None
        self.prev = None

class DoublyLL:
    def __init__(self):
        self.head = None