from collections import deque


deque.append(5)