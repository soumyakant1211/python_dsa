class Node:
    def __init__(self,data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def insertAtHead(self,data):
        pass

    def insertAtIndex(self,data,index):
        pass

    # Remove
    # Search
    # Update 

    def updateNode(self,valToUpdate,index):
        pass

    def print_LL(self):
        pass

    def length_LL(self):
        pass


ll1 = LinkedList()

ll1.insertAtHead